declare const process: {
  env: Record<string, string | undefined>;
};