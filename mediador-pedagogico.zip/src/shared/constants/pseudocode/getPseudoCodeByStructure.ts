import { OperationCode } from "./typesPseudoCode";
import { getSecuenciaCode } from "./secuenciaCode";
import { getListaSimplementeEnlazadaCode } from "./listaSimplementeEnlazadaCode";
import { getListaDoblementeEnlazadaCode } from "./listDoblementeEnlazadaCode";
import { getListaCircularSimplementeEnlazadaCode } from "./listaCircularSimplementeEnlazadaCode";
import { getListaCircularDoblementeEnlazadaCode } from "./listaCircularDoblementeEnlazadaCode";
import { getPilaCode } from "./pilaCode";
import { getColaCode } from "./colaCode";
import { getColaPrioridadCode } from "./colaPrioridadCode";
import { getTablaHashCode } from "./tablaHashCode";
import { getArbolBinarioCode } from "./arbolBinarioCode";
import { getArbolBinarioBusquedaCode } from "./arbolBinarioBusquedaCode";
import { getArbolAVLCode } from "./arbolAVLCode";
import { getArbolRNCode } from "./arbolRNCode";
import { getArbolNarioCode } from "./arbolNarioCode";
import { getArbol123Code } from "./arbol123Code";
import { getArbolBCode } from "./arbolBCode";
import { getArbolBPlusCode } from "./arbolBPlusCode";
import { getArbolHeapCode } from "./arbolHeapCode";
import { getArbolSplayCode } from "./arbolSplayCode";

// Mapa de funciones para cargar operaciones según estructura
const pseudoCodeLoaders: Record<string, () => Record<string, OperationCode>> = {
  secuencia: getSecuenciaCode,
  lista_simplemente_enlazada: getListaSimplementeEnlazadaCode,
  lista_doblemente_enlazada: getListaDoblementeEnlazadaCode,
  lista_circular_simplemente_enlazada: getListaCircularSimplementeEnlazadaCode,
  lista_circular_doblemente_enlazada: getListaCircularDoblementeEnlazadaCode,
  pila: getPilaCode,
  cola: getColaCode,
  "cola de prioridad": getColaPrioridadCode,
  tabla_hash: getTablaHashCode,
  arbol_binario: getArbolBinarioCode,
  arbol_binario_busqueda: getArbolBinarioBusquedaCode,
  arbol_avl: getArbolAVLCode,
  arbol_rojinegro: getArbolRNCode,
  arbol_splay: getArbolSplayCode,
  arbol_nario: getArbolNarioCode,
  arbol_123: getArbol123Code,
  arbol_b: getArbolBCode,
  arbol_b_plus: getArbolBPlusCode,
  arbol_heap: getArbolHeapCode,
};

// Devuelve el pseudocódigo correspondiente, o {} si no existe
export const getPseudoCodeByStructure = (structure: string): Record<string, OperationCode> => {
  const loader = pseudoCodeLoaders[structure];
  return loader ? loader() : {};
};

// Alias export para mantener compatibilidad con imports existentes
export const operationsCode = pseudoCodeLoaders;
